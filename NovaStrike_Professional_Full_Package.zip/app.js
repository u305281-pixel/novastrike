// Local DB
function getData(key){
return JSON.parse(localStorage.getItem(key)) || [];
}

function saveData(key,data){
localStorage.setItem(key,JSON.stringify(data));
}

// Register Team
function registerTeam(){
let name=document.getElementById("teamName").value;
let players=document.getElementById("playerCount").value;

let teams=getData("teams");
teams.push({name,players});
saveData("teams",teams);
loadTeams();
}

// Load Teams
function loadTeams(){
let teams=getData("teams");
let div=document.getElementById("teams");
div.innerHTML="";
teams.forEach(t=>{
let box=document.createElement("div");
box.innerHTML=`<h3>${t.name}</h3><p>Oyuncu: ${t.players}</p>`;
div.appendChild(box);
});
}

// Admin
function showAdmin(){
document.getElementById("adminPanel").style.display="block";
}

function loginAdmin(){
let pass=document.getElementById("adminPass").value;
if(pass==="1234"){
document.getElementById("adminContent").style.display="block";
}
}

function addNews(){
let text=document.getElementById("newsInput").value;
let news=getData("news");
news.push(text);
saveData("news",news);
loadNews();
}

function loadNews(){
let news=getData("news");
let div=document.getElementById("news");
div.innerHTML="";
news.forEach(n=>{
let box=document.createElement("div");
box.innerHTML=`<p>${n}</p>`;
div.appendChild(box);
});
}

loadTeams();
loadNews();
