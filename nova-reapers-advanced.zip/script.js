
function loginAlert() {
    alert("Google login sistemi demo sürümde aktif değil.");
}

function addPlayer() {
    const name = document.getElementById("playerName").value;
    if(name === "") return alert("Oyuncu adı gir!");
    const li = document.createElement("li");
    li.textContent = name;
    document.getElementById("playerList").appendChild(li);
    document.getElementById("playerName").value = "";
}

function addLeague() {
    const name = document.getElementById("leagueName").value;
    if(name === "") return alert("Lig adı gir!");
    const li = document.createElement("li");
    li.textContent = name + " - Active";
    document.getElementById("leagueList").appendChild(li);
    document.getElementById("leagueName").value = "";
}

function simulateStats() {
    const kills = Math.floor(Math.random() * 15);
    const headshot = Math.floor(Math.random() * 100);
    const winrate = Math.floor(Math.random() * 50);
    document.getElementById("statsBox").innerHTML =
        "<p>Kill: " + kills + "</p>" +
        "<p>Headshot %: " + headshot + "</p>" +
        "<p>Kazanma Oranı %: " + winrate + "</p>";
}
